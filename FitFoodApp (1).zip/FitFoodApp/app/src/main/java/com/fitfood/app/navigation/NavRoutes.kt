package com.fitfood.app.navigation

object NavRoutes {
    const val SPLASH    = "splash"
    const val LOGIN     = "login"
    const val REGISTER  = "register"
    const val HOME      = "home"
    const val DETAIL    = "detail/{recipeId}"
    const val SEARCH    = "search"
    const val FAVORITES = "favorites"
    const val PROFILE   = "profile"

    fun detailRoute(recipeId: String) = "detail/$recipeId"
}