package com.fitfood.app.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.fitfood.app.navigation.NavRoutes
import com.fitfood.app.ui.theme.GrayMedium
import com.fitfood.app.ui.theme.OrangeVibrant
import com.fitfood.app.ui.theme.White

data class BottomNavItem(
    val label  : String,
    val icon   : ImageVector,
    val route  : String
)

@Composable
fun BottomNavBar(navController: NavController) {

    val items = listOf(
        BottomNavItem("Inicio",     Icons.Default.Home,     NavRoutes.HOME),
        BottomNavItem("Buscar",     Icons.Default.Search,   NavRoutes.SEARCH),
        BottomNavItem("Favoritos",  Icons.Default.Favorite, NavRoutes.FAVORITES),
        BottomNavItem("Perfil",     Icons.Default.Person,   NavRoutes.PROFILE)
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar(
        containerColor = White,
        tonalElevation = 8.dp
    ) {
        items.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.route,
                onClick  = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(NavRoutes.HOME) { saveState = true }
                            launchSingleTop = true
                            restoreState    = true
                        }
                    }
                },
                icon  = {
                    Icon(
                        imageVector        = item.icon,
                        contentDescription = item.label
                    )
                },
                label = { Text(item.label, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor   = OrangeVibrant,
                    selectedTextColor   = OrangeVibrant,
                    unselectedIconColor = GrayMedium,
                    unselectedTextColor = GrayMedium,
                    indicatorColor      = OrangeVibrant.copy(alpha = 0.1f)
                )
            )
        }
    }
}