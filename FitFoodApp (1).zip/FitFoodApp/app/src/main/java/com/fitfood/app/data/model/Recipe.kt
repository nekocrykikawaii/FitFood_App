package com.fitfood.app.data.model

data class Recipe(
    val id           : String = "",
    val name         : String = "",
    val category     : String = "",       // "Alta proteína", "Keto", "Volumen", "Definición"
    val imageUrl     : String = "",
    val calories     : Int    = 0,
    val protein      : Int    = 0,
    val carbs        : Int    = 0,
    val fats         : Int    = 0,
    val prepTime     : String = "",
    val ingredients  : List<String> = emptyList(),
    val steps        : List<String> = emptyList(),
    val emoji        : String = "🥗"
)