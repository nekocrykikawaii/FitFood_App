package com.fitfood.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey
    val id          : String = "",
    val name        : String = "",
    val category    : String = "",
    val emoji       : String = "",
    val calories    : Int    = 0,
    val protein     : Int    = 0,
    val carbs       : Int    = 0,
    val fats        : Int    = 0,
    val prepTime    : String = "",
    val imageUrl    : String = ""
)