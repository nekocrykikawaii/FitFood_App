package com.fitfood.app.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitfood.app.data.model.Recipe
import com.fitfood.app.data.repository.RecipeRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SearchViewModel : ViewModel() {

    private val repository = RecipeRepository()

    private val _query     = MutableStateFlow("")
    val query: StateFlow<String> = _query

    private val _results   = MutableStateFlow<List<Recipe>>(emptyList())
    val results: StateFlow<List<Recipe>> = _results

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _allRecipes = MutableStateFlow<List<Recipe>>(emptyList())
    private var searchJob: Job? = null

    init {
        loadAll()
    }

    private fun loadAll() {
        viewModelScope.launch {
            _allRecipes.value = repository.getAllRecipes()
        }
    }

    fun onQueryChange(newQuery: String) {
        _query.value = newQuery
        searchJob?.cancel()
        if (newQuery.isBlank()) {
            _results.value = emptyList()
            return
        }
        // Debounce de 300ms para no buscar en cada letra
        searchJob = viewModelScope.launch {
            delay(300)
            _isLoading.value = true
            val q = newQuery.trim().lowercase()
            _results.value = _allRecipes.value.filter { recipe ->
                recipe.name.lowercase().contains(q) ||
                        recipe.ingredients.any { it.lowercase().contains(q) } ||
                        recipe.category.lowercase().contains(q)
            }
            _isLoading.value = false
        }
    }
}