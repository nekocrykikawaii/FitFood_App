package com.fitfood.app.ui.favorites

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.fitfood.app.data.model.FavoriteEntity
import com.fitfood.app.navigation.NavRoutes
import com.fitfood.app.ui.components.BottomNavBar
import com.fitfood.app.ui.theme.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import com.fitfood.app.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    navController: NavController,
    viewModel: FavoritesViewModel = viewModel()
) {
    val favorites by viewModel.favorites.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text       = "Mis Favoritos",
                        fontSize   = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color      = White
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = OrangeVibrant
                )
            )
        },
        bottomBar      = { BottomNavBar(navController = navController) },
        containerColor = GrayLight
    ) { padding ->

        when {
            favorites.isEmpty() -> {
                Box(
                    modifier         = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(text = "❤️", fontSize = 56.sp)
                        Text(
                            text       = "Aún no tienes favoritos",
                            fontSize   = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color      = GrayDark
                        )
                        Text(
                            text     = "Toca el corazón en cualquier receta\npara guardarla aquí",
                            fontSize = 14.sp,
                            color    = GrayMedium
                        )
                    }
                }
            }
            else -> {
                LazyColumn(
                    modifier       = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            text     = "${favorites.size} receta(s) guardada(s)",
                            fontSize = 13.sp,
                            color    = GrayMedium,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                    items(favorites, key = { it.id }) { favorite ->
                        FavoriteCard(
                            favorite  = favorite,
                            onClick   = {
                                navController.navigate(NavRoutes.detailRoute(favorite.id))
                            },
                            onDelete  = { viewModel.removeFavorite(favorite.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FavoriteCard(
    favorite : FavoriteEntity,
    onClick  : () -> Unit,
    onDelete : () -> Unit
) {
    Card(
        modifier  = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier          = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier         = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(OrangeLight),
                contentAlignment = Alignment.Center
            ) {
                if (favorite.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model              = favorite.imageUrl,
                        contentDescription = favorite.name,
                        contentScale       = ContentScale.Crop,
                        modifier           = Modifier.fillMaxSize(),
                        placeholder        = painterResource(id = R.drawable.ic_logo),
                        error              = painterResource(id = R.drawable.ic_logo)
                    )
                } else {
                    Text(text = favorite.emoji, fontSize = 30.sp)
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text       = favorite.name,
                    fontSize   = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color      = GrayDark,
                    maxLines   = 1,
                    overflow   = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text     = favorite.category,
                    fontSize = 12.sp,
                    color    = OrangeVibrant,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text     = "⚡ ${favorite.calories} kcal",
                        fontSize = 12.sp,
                        color    = GrayMedium
                    )
                    Text(
                        text     = "💪 ${favorite.protein}g",
                        fontSize = 12.sp,
                        color    = GrayMedium
                    )
                    Text(
                        text     = "⏱ ${favorite.prepTime}",
                        fontSize = 12.sp,
                        color    = GrayMedium
                    )
                }
            }

            // Botón eliminar
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector        = Icons.Default.Delete,
                    contentDescription = "Eliminar favorito",
                    tint               = OrangeVibrant
                )
            }
        }
    }
}