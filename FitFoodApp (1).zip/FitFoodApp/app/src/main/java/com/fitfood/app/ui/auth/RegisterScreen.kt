package com.fitfood.app.ui.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.navigation.NavController
import com.fitfood.app.R
import com.fitfood.app.navigation.NavRoutes
import com.fitfood.app.ui.theme.*
import com.google.firebase.auth.FirebaseAuth

@Composable
fun RegisterScreen(navController: NavController) {

    var name        by remember { mutableStateOf("") }
    var email       by remember { mutableStateOf("") }
    var password    by remember { mutableStateOf("") }
    var passConfirm by remember { mutableStateOf("") }
    var isLoading   by remember { mutableStateOf(false) }
    var errorMsg    by remember { mutableStateOf("") }
    var showPass    by remember { mutableStateOf(false) }

    val auth = FirebaseAuth.getInstance()

    fun doRegister() {
        when {
            name.isBlank() || email.isBlank() || password.isBlank() ->
                errorMsg = "Por favor completa todos los campos"
            password.length < 6 ->
                errorMsg = "La contraseña debe tener al menos 6 caracteres"
            password != passConfirm ->
                errorMsg = "Las contraseñas no coinciden"
            else -> {
                isLoading = true
                errorMsg  = ""
                auth.createUserWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener {
                        isLoading = false
                        navController.navigate(NavRoutes.HOME) {
                            popUpTo(NavRoutes.REGISTER) { inclusive = true }
                        }
                    }
                    .addOnFailureListener { e ->
                        isLoading = false
                        errorMsg = when {
                            e.message?.contains("email") == true ->
                                "Este correo ya está registrado"
                            else -> "Error al crear la cuenta. Intenta de nuevo"
                        }
                    }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(White)
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo superior blanco
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(White)
                    .padding(vertical = 36.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter            = painterResource(id = R.drawable.ic_logo_nombre),
                    contentDescription = "Logo",
                    modifier           = Modifier.size(110.dp),
                    contentScale       = ContentScale.Fit
                )
            }

            // Tarjeta naranja con formulario
            Card(
                modifier  = Modifier.fillMaxWidth(),
                shape     = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                colors    = CardDefaults.cardColors(containerColor = OrangeVibrant),
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 28.dp, vertical = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text       = "Crear cuenta",
                        fontSize   = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color      = White
                    )
                    Text(
                        text     = "Empieza tu journey fitness hoy",
                        fontSize = 14.sp,
                        color    = White.copy(alpha = 0.85f)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    val fieldColors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor      = White,
                        unfocusedBorderColor    = White.copy(alpha = 0.5f),
                        focusedLabelColor       = White,
                        unfocusedLabelColor     = White.copy(alpha = 0.7f),
                        cursorColor             = White,
                        focusedTextColor        = White,
                        unfocusedTextColor      = White,
                        focusedContainerColor   = White.copy(alpha = 0.15f),
                        unfocusedContainerColor = White.copy(alpha = 0.1f)
                    )

                    // Nombre
                    OutlinedTextField(
                        value         = name,
                        onValueChange = { name = it; errorMsg = "" },
                        label         = { Text("Nombre completo", color = White.copy(alpha = 0.8f)) },
                        singleLine    = true,
                        modifier      = Modifier.fillMaxWidth(),
                        shape         = RoundedCornerShape(12.dp),
                        colors        = fieldColors
                    )

                    // Correo
                    OutlinedTextField(
                        value           = email,
                        onValueChange   = { email = it; errorMsg = "" },
                        label           = { Text("Correo electrónico", color = White.copy(alpha = 0.8f)) },
                        singleLine      = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier        = Modifier.fillMaxWidth(),
                        shape           = RoundedCornerShape(12.dp),
                        colors          = fieldColors
                    )

                    // Contraseña
                    OutlinedTextField(
                        value                = password,
                        onValueChange        = { password = it; errorMsg = "" },
                        label                = { Text("Contraseña", color = White.copy(alpha = 0.8f)) },
                        singleLine           = true,
                        visualTransformation = if (showPass) VisualTransformation.None
                        else PasswordVisualTransformation(),
                        keyboardOptions      = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon         = {
                            IconButton(onClick = { showPass = !showPass }) {
                                Icon(
                                    imageVector        = if (showPass) Icons.Default.Visibility
                                    else Icons.Default.VisibilityOff,
                                    contentDescription = null,
                                    tint               = White
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape    = RoundedCornerShape(12.dp),
                        colors   = fieldColors
                    )

                    // Confirmar contraseña
                    OutlinedTextField(
                        value                = passConfirm,
                        onValueChange        = { passConfirm = it; errorMsg = "" },
                        label                = { Text("Confirmar contraseña", color = White.copy(alpha = 0.8f)) },
                        singleLine           = true,
                        visualTransformation = if (showPass) VisualTransformation.None
                        else PasswordVisualTransformation(),
                        keyboardOptions      = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon         = {
                            IconButton(onClick = { showPass = !showPass }) {
                                Icon(
                                    imageVector        = if (showPass) Icons.Default.Visibility
                                    else Icons.Default.VisibilityOff,
                                    contentDescription = null,
                                    tint               = White
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape    = RoundedCornerShape(12.dp),
                        colors   = fieldColors
                    )

                    // Error
                    if (errorMsg.isNotEmpty()) {
                        Text(
                            text     = errorMsg,
                            color    = White,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.Red.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Botón registro
                    Button(
                        onClick  = { doRegister() },
                        enabled  = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape  = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = White,
                            contentColor   = OrangeVibrant
                        )
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                color       = OrangeVibrant,
                                modifier    = Modifier.size(22.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text       = "Crear cuenta",
                                fontSize   = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color      = OrangeVibrant
                            )
                        }
                    }

                    // Link login
                    Row(
                        modifier              = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text     = "¿Ya tienes cuenta? ",
                            fontSize = 14.sp,
                            color    = White.copy(alpha = 0.85f)
                        )
                        Text(
                            text       = "Inicia sesión",
                            fontSize   = 14.sp,
                            color      = White,
                            fontWeight = FontWeight.Bold,
                            modifier   = Modifier.clickable {
                                navController.popBackStack()
                            }
                        )
                    }

                    Spacer(modifier = Modifier.navigationBarsPadding())
                }
            }
        }
    }
}