package com.fitfood.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.fitfood.app.data.model.FavoriteEntity

@Database(entities = [FavoriteEntity::class], version = 1, exportSchema = false)
abstract class FitFoodDatabase : RoomDatabase() {

    abstract fun favoriteDao(): FavoriteDao

    companion object {
        @Volatile
        private var INSTANCE: FitFoodDatabase? = null

        fun getDatabase(context: Context): FitFoodDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    FitFoodDatabase::class.java,
                    "fitfood_database"
                ).build().also { INSTANCE = it }
            }
        }
    }
}