package com.fitfood.app.data.repository

import android.content.Context
import com.fitfood.app.data.local.FitFoodDatabase
import com.fitfood.app.data.model.FavoriteEntity
import com.fitfood.app.data.model.Recipe
import kotlinx.coroutines.flow.Flow

class FavoriteRepository(context: Context) {

    private val dao = FitFoodDatabase.getDatabase(context).favoriteDao()

    fun getAllFavorites(): Flow<List<FavoriteEntity>> = dao.getAllFavorites()

    suspend fun isFavorite(id: String): Boolean = dao.isFavorite(id)

    suspend fun addFavorite(recipe: Recipe) {
        dao.addFavorite(
            FavoriteEntity(
                id       = recipe.id,
                name     = recipe.name,
                category = recipe.category,
                emoji    = recipe.emoji,
                calories = recipe.calories,
                protein  = recipe.protein,
                carbs    = recipe.carbs,
                fats     = recipe.fats,
                prepTime = recipe.prepTime,
                imageUrl = recipe.imageUrl
            )
        )
    }

    suspend fun removeFavorite(id: String) = dao.removeFavoriteById(id)
}