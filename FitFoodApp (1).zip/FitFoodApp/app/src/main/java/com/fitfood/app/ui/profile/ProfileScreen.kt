package com.fitfood.app.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.fitfood.app.navigation.NavRoutes
import com.fitfood.app.ui.components.BottomNavBar
import com.fitfood.app.ui.theme.*
import com.google.firebase.auth.FirebaseAuth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavController) {

    val auth        = FirebaseAuth.getInstance()
    val user        = auth.currentUser
    val userEmail   = user?.email ?: "Sin correo"
    val userName    = user?.displayName?.ifBlank { "Usuario Fit Food" } ?: "Usuario Fit Food"

    var showDialog  by remember { mutableStateOf(false) }

    // Diálogo de confirmación
    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Text(
                    text       = "Cerrar sesión",
                    fontWeight = FontWeight.Bold,
                    color      = GrayDark
                )
            },
            text = {
                Text(
                    text  = "¿Estás seguro que deseas cerrar sesión?",
                    color = GrayMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        auth.signOut()
                        navController.navigate(NavRoutes.LOGIN) {
                            popUpTo(0) { inclusive = true }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OrangeVibrant
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Cerrar sesión", color = White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDialog = false },
                    shape   = RoundedCornerShape(10.dp)
                ) {
                    Text("Cancelar", color = GrayDark)
                }
            },
            containerColor = White,
            shape          = RoundedCornerShape(16.dp)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text       = "Mi Perfil",
                        fontSize   = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color      = White
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = OrangeVibrant
                )
            )
        },
        bottomBar = { BottomNavBar(navController = navController) },
        containerColor = GrayLight
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Avatar
            Box(
                modifier         = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(OrangeVibrant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector        = Icons.Default.Person,
                    contentDescription = "Avatar",
                    tint               = White,
                    modifier           = Modifier.size(56.dp)
                )
            }

            // Nombre y correo
            Text(
                text       = userName,
                fontSize   = 20.sp,
                fontWeight = FontWeight.Bold,
                color      = GrayDark
            )
            Text(
                text     = userEmail,
                fontSize = 14.sp,
                color    = GrayMedium
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Card info app
            Card(
                modifier  = Modifier.fillMaxWidth(),
                shape     = RoundedCornerShape(16.dp),
                colors    = CardDefaults.cardColors(containerColor = White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text       = "Acerca de Fit Food App",
                        fontSize   = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color      = GrayDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text     = "Aplicación móvil de recetas fitness y saludables. Encuentra recetas con alto contenido proteico, keto, de definición y volumen para alcanzar tus metas.",
                        fontSize = 13.sp,
                        color    = GrayMedium,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text     = "Versión 1.0.0",
                        fontSize = 12.sp,
                        color    = OrangeVibrant,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Botón cerrar sesión
            Button(
                onClick  = { showDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape  = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = OrangeVibrant,
                    contentColor   = White
                )
            ) {
                Icon(
                    imageVector        = Icons.Default.ExitToApp,
                    contentDescription = null,
                    modifier           = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text       = "Cerrar sesión",
                    fontSize   = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}