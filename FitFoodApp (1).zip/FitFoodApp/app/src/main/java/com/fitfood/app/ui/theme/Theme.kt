package com.fitfood.app.ui.theme

import android.app.Activity
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val FitFoodColorScheme = lightColorScheme(
    primary         = OrangeVibrant,
    onPrimary       = White,
    primaryContainer = OrangeLight,
    onPrimaryContainer = OrangeDark,
    secondary       = GreenLeaf,
    onSecondary     = White,
    background      = GrayLight,
    onBackground    = GrayDark,
    surface         = White,
    onSurface       = GrayDark,
    surfaceVariant  = GrayLight,
    onSurfaceVariant = GrayMedium,
    outline         = Color(0xFFE0E0E0)
)

@Composable
fun FitFoodAppTheme(content: @Composable () -> Unit) {
    val colorScheme = FitFoodColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = White.toArgb()
            WindowCompat.getInsetsController(window, view)
                .isAppearanceLightStatusBars = true
        }
    }
    MaterialTheme(
        colorScheme = colorScheme,
        typography  = Typography,
        content     = content
    )
}