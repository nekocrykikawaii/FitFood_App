package com.fitfood.app.ui.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.fitfood.app.navigation.NavRoutes
import com.fitfood.app.ui.components.BottomNavBar
import com.fitfood.app.ui.home.RecipeCard
import com.fitfood.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    navController: NavController,
    viewModel: SearchViewModel = viewModel()
) {
    val query   by viewModel.query.collectAsState()
    val results by viewModel.results.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text       = "Buscar recetas",
                        fontSize   = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color      = White
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = OrangeVibrant
                )
            )
        },
        bottomBar  = { BottomNavBar(navController = navController) },
        containerColor = GrayLight
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Barra de búsqueda
            OutlinedTextField(
                value         = query,
                onValueChange = { viewModel.onQueryChange(it) },
                placeholder   = { Text("Buscar por ingrediente o nombre...") },
                leadingIcon   = {
                    Icon(
                        imageVector        = Icons.Default.Search,
                        contentDescription = null,
                        tint               = OrangeVibrant
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape  = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = OrangeVibrant,
                    unfocusedBorderColor = GrayLight,
                    focusedLabelColor    = OrangeVibrant,
                    cursorColor          = OrangeVibrant,
                    unfocusedContainerColor = White,
                    focusedContainerColor   = White
                ),
                singleLine = true
            )

            when {
                // Estado inicial
                query.isBlank() -> {
                    Box(
                        modifier         = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = "🔍", fontSize = 48.sp)
                            Text(
                                text     = "Escribe un ingrediente o nombre",
                                color    = GrayMedium,
                                fontSize = 15.sp
                            )
                            Text(
                                text     = "Ej: pollo, quinoa, salmón...",
                                color    = GrayMedium,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
                // Cargando
                isLoading -> {
                    Box(
                        modifier         = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = OrangeVibrant)
                    }
                }
                // Sin resultados
                results.isEmpty() -> {
                    Box(
                        modifier         = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = "😕", fontSize = 48.sp)
                            Text(
                                text     = "Sin resultados para \"$query\"",
                                color    = GrayMedium,
                                fontSize = 15.sp
                            )
                            Text(
                                text     = "Intenta con otro ingrediente",
                                color    = GrayMedium,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
                // Resultados
                else -> {
                    Text(
                        text     = "${results.size} receta(s) encontrada(s)",
                        fontSize = 13.sp,
                        color    = GrayMedium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                    LazyColumn(
                        contentPadding      = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(results) { recipe ->
                            RecipeCard(
                                recipe  = recipe,
                                onClick = {
                                    navController.navigate(
                                        NavRoutes.detailRoute(recipe.id)
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}