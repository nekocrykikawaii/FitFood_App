package com.fitfood.app.ui.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.fitfood.app.ui.theme.*
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import com.fitfood.app.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    navController : NavController,
    recipeId      : String,
    viewModel     : DetailViewModel = viewModel()
) {
    val recipe    by viewModel.recipe.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    LaunchedEffect(recipeId) {
        viewModel.loadRecipe(recipeId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title  = { Text(recipe?.name ?: "", color = White, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector        = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver",
                            tint               = White
                        )
                    }
                },
                actions = {
                    val isFav by viewModel.isFavorite.collectAsState()
                    IconButton(onClick = { viewModel.toggleFavorite() }) {
                        Icon(
                            imageVector = if (isFav) Icons.Default.Favorite
                            else Icons.Default.FavoriteBorder,
                            contentDescription = if (isFav) "Quitar favorito"
                            else "Agregar favorito",
                            tint = White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = OrangeVibrant
                )
            )
        },
        containerColor = GrayLight
    ) { padding ->

        when {
            isLoading -> {
                Box(
                    modifier         = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = OrangeVibrant)
                }
            }
            recipe == null -> {
                Box(
                    modifier         = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Receta no encontrada", color = GrayMedium)
                }
            }
            else -> {
                val r = recipe!!
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Banner imagen o emoji
                    Box(
                        modifier         = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .background(OrangeLight),
                        contentAlignment = Alignment.Center
                    ) {
                        if (r.imageUrl.isNotBlank()) {
                            AsyncImage(
                                model              = r.imageUrl,
                                contentDescription = r.name,
                                contentScale       = ContentScale.Crop,
                                modifier           = Modifier.fillMaxSize(),
                                placeholder        = painterResource(id = R.drawable.ic_logo),
                                error              = painterResource(id = R.drawable.ic_logo)
                            )
                        } else {
                            Text(text = r.emoji, fontSize = 80.sp)
                        }
                    }

                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Info básica
                        Row(
                            modifier              = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment     = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text       = r.name,
                                    fontSize   = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color      = GrayDark
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    CategoryBadge(r.category)
                                    Text(
                                        text     = "⏱ ${r.prepTime}",
                                        fontSize = 12.sp,
                                        color    = GrayMedium
                                    )
                                }
                            }
                        }

                        // Macros
                        Card(
                            shape  = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = White),
                            elevation = CardDefaults.cardElevation(2.dp)
                        ) {
                            Row(
                                modifier              = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                MacroItem(value = "${r.calories}", label = "kcal",    emoji = "⚡")
                                MacroDivider()
                                MacroItem(value = "${r.protein}g", label = "Proteína", emoji = "💪")
                                MacroDivider()
                                MacroItem(value = "${r.carbs}g",   label = "Carbos",   emoji = "🌾")
                                MacroDivider()
                                MacroItem(value = "${r.fats}g",    label = "Grasas",   emoji = "🥑")
                            }
                        }

                        // Ingredientes
                        SectionCard(title = "🛒 Ingredientes") {
                            r.ingredients.forEachIndexed { index, ingredient ->
                                Row(
                                    modifier          = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier         = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(OrangeVibrant)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text     = ingredient,
                                        fontSize = 14.sp,
                                        color    = GrayDark
                                    )
                                }
                                if (index < r.ingredients.lastIndex) {
                                    HorizontalDivider(
                                        color     = GrayLight,
                                        thickness = 0.5.dp
                                    )
                                }
                            }
                        }

                        // Pasos
                        SectionCard(title = "👨‍🍳 Preparación") {
                            r.steps.forEachIndexed { index, step ->
                                Row(
                                    modifier          = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    // Número del paso
                                    Box(
                                        modifier         = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(OrangeVibrant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text       = "${index + 1}",
                                            color      = White,
                                            fontSize   = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text       = step,
                                        fontSize   = 14.sp,
                                        color      = GrayDark,
                                        lineHeight = 20.sp,
                                        modifier   = Modifier.weight(1f)
                                    )
                                }
                                if (index < r.steps.lastIndex) {
                                    HorizontalDivider(
                                        color     = GrayLight,
                                        thickness = 0.5.dp,
                                        modifier  = Modifier.padding(start = 40.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryBadge(category: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(OrangeVibrant)
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(text = category, fontSize = 11.sp, color = White)
    }
}

@Composable
fun MacroItem(value: String, label: String, emoji: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = emoji, fontSize = 18.sp)
        Text(
            text       = value,
            fontSize   = 16.sp,
            fontWeight = FontWeight.Bold,
            color      = GrayDark
        )
        Text(text = label, fontSize = 11.sp, color = GrayMedium)
    }
}

@Composable
fun MacroDivider() {
    Box(
        modifier = Modifier
            .width(0.5.dp)
            .height(48.dp)
            .background(GrayLight)
    )
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier  = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text       = title,
                fontSize   = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color      = GrayDark
            )
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}