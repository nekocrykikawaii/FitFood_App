package com.fitfood.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.fitfood.app.data.model.Recipe
import com.fitfood.app.navigation.NavRoutes
import com.fitfood.app.ui.theme.*
import androidx.compose.foundation.lazy.LazyRow
import com.fitfood.app.ui.components.BottomNavBar
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import com.fitfood.app.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel = viewModel()
) {
    val recipes        by viewModel.recipes.collectAsState()
    val isLoading      by viewModel.isLoading.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text       = "Fit Food App",
                            fontSize   = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color      = White
                        )
                        Text(
                            text     = "Recetas fitness y saludables",
                            fontSize = 12.sp,
                            color    = White.copy(alpha = 0.85f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = OrangeVibrant
                )
            )
        },
        bottomBar = { BottomNavBar(navController = navController) },
        containerColor = GrayLight
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Chips de filtro
            LazyRow(
                modifier            = Modifier
                    .fillMaxWidth()
                    .background(White)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(viewModel.filters) { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick  = { viewModel.selectFilter(filter) },
                        label    = { Text(text = filter, fontSize = 13.sp) },
                        colors   = FilterChipDefaults.filterChipColors(
                            selectedContainerColor    = OrangeVibrant,
                            selectedLabelColor        = White,
                            containerColor            = GrayLight,
                            labelColor                = GrayDark
                        ),
                        shape    = RoundedCornerShape(20.dp)
                    )
                }
            }

            // Contenido
            when {
                isLoading -> {
                    Box(
                        modifier          = Modifier.fillMaxSize(),
                        contentAlignment  = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = OrangeVibrant)
                    }
                }
                recipes.isEmpty() -> {
                    Box(
                        modifier          = Modifier.fillMaxSize(),
                        contentAlignment  = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "🥗", fontSize = 48.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text     = "No hay recetas en esta categoría",
                                color    = GrayMedium,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
                else -> {
                    LazyVerticalGrid(
                        columns             = GridCells.Fixed(2),
                        contentPadding      = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement   = Arrangement.spacedBy(10.dp),
                        modifier            = Modifier.fillMaxSize()
                    ) {
                        items(recipes) { recipe ->
                            RecipeCard(
                                recipe  = recipe,
                                onClick = {
                                    navController.navigate(
                                        NavRoutes.detailRoute(recipe.id)
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RecipeCard(recipe: Recipe, onClick: () -> Unit) {
    Card(
        modifier  = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            // Imagen con Coil o emoji de fallback
            Box(
                modifier         = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .background(OrangeLight),
                contentAlignment = Alignment.Center
            ) {
                if (recipe.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model              = recipe.imageUrl,
                        contentDescription = recipe.name,
                        contentScale       = ContentScale.Crop,
                        modifier           = Modifier.fillMaxSize(),
                        placeholder        = painterResource(id = R.drawable.ic_logo),
                        error              = painterResource(id = R.drawable.ic_logo)
                    )
                } else {
                    Text(
                        text     = recipe.emoji,
                        fontSize = 48.sp
                    )
                }

                // Badge categoría
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(OrangeVibrant)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text     = recipe.category,
                        fontSize = 9.sp,
                        color    = White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Column(
                modifier            = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text       = recipe.name,
                    fontSize   = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color      = GrayDark,
                    maxLines   = 2,
                    overflow   = TextOverflow.Ellipsis
                )
                Row(
                    verticalAlignment      = Alignment.CenterVertically,
                    horizontalArrangement  = Arrangement.SpaceBetween,
                    modifier               = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text       = "⚡ ${recipe.calories} kcal",
                        fontSize   = 11.sp,
                        color      = OrangeVibrant,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text     = "⏱ ${recipe.prepTime}",
                        fontSize = 11.sp,
                        color    = GrayMedium
                    )
                }
            }
        }
    }
}