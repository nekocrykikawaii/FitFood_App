package com.fitfood.app.ui.splash

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.fitfood.app.R
import com.fitfood.app.navigation.NavRoutes
import com.fitfood.app.ui.theme.White
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(navController: NavController) {

    // Animación de escala
    val scale = remember { Animatable(0.6f) }
    // Animación de opacidad
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        // Animar entrada del logo
        launch {
            scale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness    = Spring.StiffnessLow
                )
            )
        }
        launch {
            alpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 700)
            )
        }

        // Esperar 2.5 segundos
        delay(2500)

        // Decidir a dónde navegar
        val user = FirebaseAuth.getInstance().currentUser
        val destination = if (user != null) NavRoutes.HOME else NavRoutes.LOGIN

        navController.navigate(destination) {
            popUpTo(NavRoutes.SPLASH) { inclusive = true }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(White),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_logo_nombre),
            contentDescription = "Fit Food App",
            modifier = Modifier
                .width(260.dp)
                .scale(scale.value)
                .alpha(alpha.value)
        )
    }
}