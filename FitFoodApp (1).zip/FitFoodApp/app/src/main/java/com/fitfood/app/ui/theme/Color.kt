package com.fitfood.app.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta Fit Food App
val OrangeVibrant  = Color(0xFFFF9800)
val OrangeDark     = Color(0xFFE65100)
val OrangeLight    = Color(0xFFFFF3E0)
val GrayDark       = Color(0xFF333333)
val GrayMedium     = Color(0xFF888888)
val GrayLight      = Color(0xFFF8F8F8)
val GreenLeaf      = Color(0xFF5A9E2F)
val White          = Color(0xFFFFFFFF)
val Black          = Color(0xFF000000)