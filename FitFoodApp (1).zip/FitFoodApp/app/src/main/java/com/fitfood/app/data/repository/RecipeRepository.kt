package com.fitfood.app.data.repository

import com.fitfood.app.data.model.Recipe
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class RecipeRepository {

    private val db = FirebaseFirestore.getInstance()
    private val collection = db.collection("recipes")

    suspend fun getAllRecipes(): List<Recipe> {
        return try {
            collection.get().await().documents.mapNotNull { doc ->
                doc.toObject(Recipe::class.java)?.copy(id = doc.id)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getRecipesByCategory(category: String): List<Recipe> {
        return try {
            collection
                .whereEqualTo("category", category)
                .get().await()
                .documents.mapNotNull { doc ->
                    doc.toObject(Recipe::class.java)?.copy(id = doc.id)
                }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getRecipeById(id: String): Recipe? {
        return try {
            val doc = collection.document(id).get().await()
            doc.toObject(Recipe::class.java)?.copy(id = doc.id)
        } catch (e: Exception) {
            null
        }
    }
}