package com.fitfood.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.fitfood.app.ui.auth.LoginScreen
import com.fitfood.app.ui.auth.RegisterScreen
import com.fitfood.app.ui.detail.DetailScreen
import com.fitfood.app.ui.favorites.FavoritesScreen
import com.fitfood.app.ui.home.HomeScreen
import com.fitfood.app.ui.profile.ProfileScreen
import com.fitfood.app.ui.search.SearchScreen
import com.fitfood.app.ui.splash.SplashScreen

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(
        navController    = navController,
        startDestination = NavRoutes.SPLASH
    ) {
        composable(NavRoutes.SPLASH) {
            SplashScreen(navController = navController)
        }
        composable(NavRoutes.LOGIN) {
            LoginScreen(navController = navController)
        }
        composable(NavRoutes.REGISTER) {
            RegisterScreen(navController = navController)
        }
        composable(NavRoutes.HOME) {
            HomeScreen(navController = navController)
        }
        composable(
            route     = NavRoutes.DETAIL,
            arguments = listOf(navArgument("recipeId") { type = NavType.StringType })
        ) { backStackEntry ->
            val recipeId = backStackEntry.arguments?.getString("recipeId") ?: ""
            DetailScreen(navController = navController, recipeId = recipeId)
        }
        composable(NavRoutes.SEARCH) {
            SearchScreen(navController = navController)
        }
        composable(NavRoutes.FAVORITES) {
            FavoritesScreen(navController = navController)
        }
        composable(NavRoutes.PROFILE) {
            ProfileScreen(navController = navController)
        }
    }
}