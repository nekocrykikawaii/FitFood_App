package com.fitfood.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitfood.app.data.model.Recipe
import com.fitfood.app.data.repository.RecipeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {

    private val repository = RecipeRepository()

    private val _allRecipes    = MutableStateFlow<List<Recipe>>(emptyList())
    private val _recipes       = MutableStateFlow<List<Recipe>>(emptyList())
    val recipes: StateFlow<List<Recipe>> = _recipes

    private val _isLoading     = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _selectedFilter = MutableStateFlow("Todos")
    val selectedFilter: StateFlow<String> = _selectedFilter

    val filters = listOf("Todos", "Alta proteína", "Definición", "Keto", "Volumen")

    init {
        loadRecipes()
    }

    private fun loadRecipes() {
        viewModelScope.launch {
            _isLoading.value = true
            _allRecipes.value = repository.getAllRecipes()
            _recipes.value    = _allRecipes.value
            _isLoading.value  = false
        }
    }

    fun selectFilter(filter: String) {
        _selectedFilter.value = filter
        _recipes.value = if (filter == "Todos") {
            _allRecipes.value
        } else {
            _allRecipes.value.filter { it.category == filter }
        }
    }
}