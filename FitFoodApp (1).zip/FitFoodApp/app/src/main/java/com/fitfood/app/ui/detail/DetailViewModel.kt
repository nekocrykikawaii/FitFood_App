package com.fitfood.app.ui.detail

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fitfood.app.data.model.Recipe
import com.fitfood.app.data.repository.FavoriteRepository
import com.fitfood.app.data.repository.RecipeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class DetailViewModel(application: Application) : AndroidViewModel(application) {

    private val recipeRepo   = RecipeRepository()
    private val favoriteRepo = FavoriteRepository(application)

    private val _recipe      = MutableStateFlow<Recipe?>(null)
    val recipe: StateFlow<Recipe?> = _recipe

    private val _isLoading   = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _isFavorite  = MutableStateFlow(false)
    val isFavorite: StateFlow<Boolean> = _isFavorite

    fun loadRecipe(id: String) {
        viewModelScope.launch {
            _isLoading.value  = true
            _recipe.value     = recipeRepo.getRecipeById(id)
            _isFavorite.value = favoriteRepo.isFavorite(id)
            _isLoading.value  = false
        }
    }

    fun toggleFavorite() {
        val recipe = _recipe.value ?: return
        viewModelScope.launch {
            if (_isFavorite.value) {
                favoriteRepo.removeFavorite(recipe.id)
            } else {
                favoriteRepo.addFavorite(recipe)
            }
            _isFavorite.value = !_isFavorite.value
        }
    }
}